

<?php $__env->startSection('content'); ?>
<div class="card-header">مدیریت دسته ها</div>

<div class="card-body">
    <a href="<?php echo e(route('option.create')); ?>" class="btn btn-primary">اضافه کردن کوپن جدید</a>
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <div class="row">
                <div class="col-md-3">نام: <?php echo e($option->name); ?></div>
                <div class="col-md-3">توضیحات: <?php echo e($option->content); ?></div>
                <div class="col-md-3">
                    <form action="<?php echo e(route('option.destroy', $option->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm btn-danger">حذف</button>
                    </form>
                    <a href="<?php echo e(route('option.edit', $option->id)); ?>" class="btn btn-sm btn-primary">ویرایش</a>
                </div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($options->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/admin/option/index.blade.php ENDPATH**/ ?>