  
<div class="card-header">منو</div>

<div class="card-body">
    <div class="userinfo">
        <?php echo e(getUserTumbnail()); ?>

        <div class="wallet">
            <p>کیف پول: <?php echo e(auth()->user()->wallet); ?> تومان</p>
            <a href="<?php echo e(route('user.wallet')); ?>" class="btn btn-sm btn-danger">شارژ کیف پول</a>
        </div>
    </div>
    <div class="sidenav mt-2">
        <a href="<?php echo e(route('home')); ?>"><i class="fa fa-tachometer"></i> پنل کاربری</a>
        <a href="<?php echo e(route('user.send_question')); ?>"><i class="fa fa-comment"></i> ارسال سوال</a>
        <a href="<?php echo e(route('user.transactions')); ?>"><i class="fas fa-money-bill-alt"></i> تراکنش ها</a>
        <a href="<?php echo e(route('user.requests')); ?>"><i class="fas fa-list"></i> سوالات</a>
        <a href="<?php echo e(route('user.wallet')); ?>"><i class="fas fa-wallet"></i> کیف پول</a>
        <button class="dropdown-btn"> اطلاعات حساب
            <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
            <a href="<?php echo e(route('user.data')); ?>">ویرایش اطلاعات</a>
            <a href="<?php echo e(route('user.password')); ?>">تغییر رمز عبو</a>
        </div>
     
        <?php if(request()->user()->can('admin') || request()->user()->can('superadmin') || request()->user()->can('expert')): ?>
        <hr data-content="امکانات ادمین" class="hr-text">
        <a href="<?php echo e(route('request.index')); ?>"><i class="fas fa-list"></i> سوالات</a>
        <a href="<?php echo e(route('comment.index')); ?>"><i class="fas fa-comment"></i> پاسخ ها</a>
        <?php endif; ?>
        <?php if(request()->user()->can('admin') || request()->user()->can('superadmin') || request()->user()->can('expert_two')): ?>
        <hr data-content="کارشناس دوم" class="hr-text">
        <a href="<?php echo e(route('comment.reject')); ?>"><i class="fas fa-list"></i> سوالات ارجاعی</a>
        <?php endif; ?>
        <?php if(request()->user()->can('admin') || request()->user()->can('superadmin')): ?>
        <hr data-content="ادمین" class="hr-text">
        <button class="dropdown-btn"> کاربران 
            <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
            <a href="<?php echo e(route('user.index')); ?>">همه کاربران</a>
            <a href="<?php echo e(route('register')); ?>#customer">افزودن کاربر</a>
            <a href="<?php echo e(route('register')); ?>#expert">افزودن کارشناس</a>
        </div>
        <a href="<?php echo e(route('transaction.index')); ?>"><i class="fas fa-money-bill-alt"></i> تراکنش ها</a>
        <a href="<?php echo e(route('wallet_order')); ?>"><i class="fas fa-money-bill-alt"></i> درخواست پول</a>
        <a href="<?php echo e(route('coupon.index')); ?>"><i class="fas fa-money-bill-alt"></i> کد های تخفیف</a>
        <a href="<?php echo e(route('option.index')); ?>"><i class="fas fa-cog"></i> دسته ها</a>
        
        <?php endif; ?>
    </div>

</div>
          
       
   
<?php /**PATH C:\xampp\htdocs\view\resources\views/partials/menu.blade.php ENDPATH**/ ?>