

<?php $__env->startSection('content'); ?>


<div class="card-header">سوالات</div>

<div class="card-body">
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item <?php if(!$req->status): ?> border border-danger <?php endif; ?>">
            <div class="row">
                <div class="table-responsive col-md-5">
                    <table class="table-bordered">
                        <tr>
                            <th class="p-2">دسته</th>
                            <td class="p-2"><?php echo e($req->transaction->optionVar->option->name); ?> <br> <?php echo e($req->transaction->optionVar->name); ?></td>
                            <td class="p-2"><?php echo e($req->transaction->optionType->name); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">عنوان</th>
                            <td class="p-2"><?php echo e($req->title); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">جنس</th>
                            <td class="p-2"><?php echo e($req->getMeta('material', true)); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">وزن</th>
                            <td class="p-2"><?php echo e($req->getMeta('weight', true)); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="table-responsive col-md-4">
                    <table class="table-bordered">
                        <tr>
                            <th class="p-2">نام</th>
                            <td class="p-2"><?php echo e($req->getMeta('name', true)); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">نژاد</th>
                            <td class="p-2"><?php echo e($req->getMeta('race', true)); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">سن</th>
                            <td class="p-2"><?php echo e($req->getMeta('age', true)); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">تاریخ</th>
                            <td class="p-2"><?php echo e($req->created_at); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="table-responsive col-md-3">
                    <table class="table-bordered">
                        <tr>
                            <th class="p-2">
                            <a href="<?php echo e(route('user.request', $req->id)); ?>" class="btn btn-primary">مشاهده </a>
                            <?php if(auth()->user()->can('update', $req) || auth()->user()->can('admin')): ?>
                            <a href="<?php echo e(route('user.question_request', $req->transaction->id)); ?>" class="btn btn-warning">ویرایش </a>
                            <?php endif; ?>
                            <br>
                                وضعیت: <a href="#" class="text-danger"><?php echo e(__('app.'.$req->status)); ?></a>
                            </th>
                        </tr>
                    </table>
                </div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($requests->links()); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/customer/request/index.blade.php ENDPATH**/ ?>