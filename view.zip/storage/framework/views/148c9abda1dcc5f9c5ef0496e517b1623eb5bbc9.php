<div class="modal fade popupviewer" tabindex="-1" role="dialog" aria-labelledby="popupviewer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
  
    <div class="modal-content">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <p class="modal-title" id="myLargeModalLabel">مشاهده گر تصویر</p>
      </div>
        
    <div class="modal-body">
        <?php echo $__env->make('partials.viewer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\view\resources\views/partials/popupviewer.blade.php ENDPATH**/ ?>