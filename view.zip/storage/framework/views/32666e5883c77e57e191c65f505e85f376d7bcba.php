


<?php $__env->startSection('content'); ?>
<div class="card-header">تغییر رمز عبور</div>

<div class="card-body">
    <form method="POST" enctype="multipart/form-data" action="<?php echo e(($userid) ? route('user.a_change_password', $userid) : route('user.change_password')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
        <?php if(!$userid): ?>
        <div class="form-group row">
            <label for="old_password" class="col-md-4 col-form-label text-md-right">رمز عبور فعلی <strong class="text-danger">*</strong></label>

            <div class="col-md-6">
                <input id="old_password" type="text" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="old_password" value="<?php echo e(old('old_password')); ?>" required autocomplete="name" autofocus>

                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="form-group row">
            <label for="new_password" class="col-md-4 col-form-label text-md-right">رمز عبور جدید <strong class="text-danger">*</strong></label>

            <div class="col-md-6">
                <input id="new_password" type="text" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password" value="<?php echo e(old('new_password')); ?>" required autocomplete="name" autofocus>

                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
   
        <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn border-primary text-primary">
                    تغییر
                </button>
            </div>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/auth/change-password.blade.php ENDPATH**/ ?>