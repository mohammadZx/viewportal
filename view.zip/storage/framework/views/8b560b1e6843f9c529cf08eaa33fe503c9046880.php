

<?php $__env->startSection('content'); ?>


<div class="card-header">درخواست: <?php echo e($request->title); ?></div>

<div class="card-body">
<div class="section">
       <div class="label">وضعیت: <?php echo e(__('app.'.$request->status)); ?></div>
   </div>
   <div class="section">
        <div class="content">
        توضیحات: <?php echo $request->content; ?>

        </div>
   </div>
   <hr>
 <div class="row">
     <div class="col-md-3">
         نام حیوان: <?php echo e($request->getMeta('name', true)); ?>

     </div>
     <div class="col-md-3">
        سن حیوان: <?php echo e($request->getMeta('age', true)); ?>

     </div>
     <div class="col-md-3">
        جنس : <?php echo e($request->getMeta('material', true)); ?>

     </div>
     <div class="col-md-3">
     نژاد : <?php echo e($request->getMeta('race', true)); ?>

     </div>
     <div class="col-md-3">
     وزن : <?php echo e($request->getMeta('weight', true)); ?>

     </div>
     <div class="col-md-3">
     سابقه : <?php echo e($request->getMeta('history', true)); ?>

     </div>
 </div>
 <hr>
 <div class="row attachment images">
     <?php $__currentLoopData = $request->getMeta('attachment'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php $attachmentById = getAttachmentById($image->meta_value); ?>
     <?php if(istype($attachmentById, 'image')): ?>
            <div class="col-md-3">
            <button class="btn btn-viewer" data-src="<?php echo e($attachmentById); ?>" type="button" data-toggle="modal" data-target=".popupviewer"><i class="fa fa-eye"></i></button>
            <img src="<?php echo e($attachmentById); ?>" alt="">
            </div>
        <?php endif; ?>
        <?php if(istype($attachmentById, 'audio')): ?>
            <div class="col-md-6">
            <audio src="<?php echo e($attachmentById); ?>" controls preload="none"></audio>
            </div>
        <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
 <hr>
 <div class="meta-items d-flex flex-wrap">
        <div class="meta">دسته: <?php echo e($request->transaction->optionVar->option->name); ?></div>&nbsp;&nbsp;&nbsp;&nbsp;
        <div class="meta">نوع: <?php echo e($request->transaction->optionVar->name); ?></div>&nbsp;&nbsp;&nbsp;&nbsp;
        <div class="meta">پلن: <?php echo e($request->transaction->optionType->name); ?></div>&nbsp;&nbsp;&nbsp;&nbsp;
        <div class="meta">قیمت: <?php echo e($request->transaction->price); ?></div>&nbsp;&nbsp;&nbsp;&nbsp;
 </div>
 <hr>
 <div class="comments">
     <div class="title">
         پاسخ ها:
     </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addcomment', $request)): ?>
            <?php echo $__env->make('partials.commentform', ['request' => $request], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

     <?php echo $__env->make('partials.comments', ['comments' => $request->comments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/customer/request/show.blade.php ENDPATH**/ ?>