<?php $__env->startSection('content'); ?>

        
    <div class="card-header"><?php echo e(__('app.dashboard')); ?></div>

    <div class="card-body">

        <?php if(auth()->user()->getMeta('status', true) == 'disable'): ?>
            <div class="alert alert-danger">
            <i class="fa fa-exclamation-circle" aria-hidden="true"></i> 
                کارشناس گرامی. حساب شما در حال حاضر غیر فعال می باشد و پس از تایید مدیران می توانید فعالیت خود را در سایت شروع کنید.
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-sm-6 mt-3">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($allTransactions); ?> کیس ها</h5>
                    <a href="<?php echo e(route('user.transactions')); ?>" class="btn btn-primary">مشاهده</a>
                </div>
                </div>
            </div>
            <div class="col-sm-6 mt-3">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e(auth()->user()->wallet); ?>  کیف پول</h5>
                    <a href="<?php echo e(route('user.wallet')); ?>" class="btn btn-primary">شارژ</a>
                </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 mt-3">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($requests); ?>  سوالات</h5>
                    <a href="<?php echo e(route('user.requests')); ?>" class="btn btn-primary">مشاهده</a>
                </div>
                </div>
            </div>
            <div class="col-sm-6 mt-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($faildTransactions); ?>  تراکنش های ناموفق</h5>
                        <a href="<?php echo e(route('user.transactions')); ?>" class="btn btn-primary">مشاهده</a>
                    </div>
                </div>
            </div>
        </div>
            
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/home.blade.php ENDPATH**/ ?>