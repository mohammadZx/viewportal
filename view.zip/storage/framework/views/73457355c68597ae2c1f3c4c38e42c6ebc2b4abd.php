

<?php $__env->startSection('content'); ?>


<div class="card-header">سوالات</div>

<div class="card-body">
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <div class="row">
                <div class="col-md-3">پاسخ دهنده: <?php echo e($comment->user->name); ?></div>
                <div class="col-md-3">عنوان: <?php echo e($comment->request->title); ?></div>
                <div class="col-md-3"><a href="<?php echo e(route('user.request', $comment->request->id)); ?>" class="btn btn-sm btn-primary">مشاهده</a></div>
                <div class="col-md-3"><a href="<?php echo e(route('comment.edit', $comment->id)); ?>" class="btn btn-sm btn-warning">ویرایش</a></div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($comments->links()); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/customer/comment/index.blade.php ENDPATH**/ ?>