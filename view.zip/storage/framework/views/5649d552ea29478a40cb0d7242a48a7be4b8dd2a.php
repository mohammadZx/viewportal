

<?php $__env->startSection('content'); ?>
<div class="card-header">مدیریت کاربران</div>

<div class="card-body">
    <form action="" class="search row">
        <div class="col-md-3"><input type="text" name="search" placeholder="جستجوی کاربران" class="form-control" <?php if(request()->has('search')): ?> value="<?php echo e(request()->get('search')); ?>" <?php endif; ?>></div> 
        <div class="col-md-3"><button class="btn btn-primary">ثبت</button></div>
    </form>
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item <?php if($user->getMeta('status', true) == 'disable'): ?> border border-secondary <?php endif; ?>">
            <div class="row">
                <div class="col-md-6"><a href="<?php echo e(route('user.show', $user->id)); ?>" class="h5"><?php echo e($user->name); ?></a> - <strong class="text-danger"><?php echo e(__('auth.'. $user->role)); ?></strong></div>
                <div class="col-md-6"><span class="h5">تراکنش ها: <?php echo e($user->transactions()->count()); ?></span> - <strong class="text-danger"><?php echo e(__('auth.'. $user->role)); ?></strong></div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('see-user')): ?>
                <a href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-sm btn-primary">نمایش</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
                <a href="<?php echo e(route('user.a_password', $user->id)); ?>" class="btn btn-sm btn-warning">ویرایش رمز</a>
                <a href="<?php echo e(route('user.a_data', $user->id)); ?>" class="btn btn-sm btn-warning">ویرایش</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-user')): ?>
                <form method="post" action="<?php echo e(route('user.destroy', $user->id)); ?>" class="confirm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-sm btn-danger">حذف</button>
                </form>
                <?php endif; ?>
            </div>
            <div class="row mt-3">
                <div class="info">
                    <p>تلفن: <?php echo e($user->phone); ?></p>
                    <p>ایمیل: <?php echo e($user->email); ?></p>
                    <p>کیف پول: <?php echo e($user->wallet); ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?> <button class="btn btn-sm btn-warning toggleclass" data-class=".wallet-clear-form">تسویه</button><?php endif; ?></p>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
            <div class="wallet-clear-form unactive">
                <form action="<?php echo e(route('user.clear-wallet', $user->id)); ?>" class="row" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-4"><input type="text" name="authority" required placeholder="کد پیگیری" class="form-control"></div>
                    <div class="col-md-4"><input type="text" name="comment" placeholder="توضیحات" class="form-control"></div>
                    <div class="col-md-4"><button class="btn btn-primary">ارسال</button></div>
                </form>
            </div>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($users->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/admin/user/index.blade.php ENDPATH**/ ?>