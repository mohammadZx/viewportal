
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="display-comment">
    <strong><span class="name"><?php echo e($comment->user->name); ?></span> | <span class="time"><?php echo e($comment->created_at); ?></span> | <span class="type">عنوان: <?php echo e(__('auth.'.$comment->user->role)); ?></span></strong>
    <br>
    <table class="table table-bordered">
        <tr>
            <th>Status</th>
            <td><?php echo e($comment->getMeta('status', true) ? 'تایید شده توسط کارشناس دوم' : 'بدون وضعیت'); ?></td>
        </tr>
        <tr>
            <th>Graph</th>
            <td><?php echo e($comment->getMeta('graph', true)); ?></td>
        </tr>
        <tr>
            <th>Tech</th>
            <td><?php echo e($comment->tech); ?></td>
        </tr>
        <tr>
            <th>Interpretation</th>
            <td><?php echo e($comment->interpretation); ?></td>
        </tr>
        <tr>
            <th>Diagnosis</th>
            <td><?php echo e($comment->diagnosis); ?></td>
        </tr>
        <tr>
            <th>Comment</th>
            <td><?php echo $comment->content; ?></td>
        </tr>
    </table>

    <div class="row attachment comment images">
     <?php $__currentLoopData = $comment->getMeta('attachment'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php $attachmentById = getAttachmentById($image->meta_value); ?>
        <?php if(istype($attachmentById, 'image')): ?>
            <div class="col-md-3">
            <button class="btn btn-viewer" data-src="<?php echo e($attachmentById); ?>" type="button" data-toggle="modal" data-target=".popupviewer"><i class="fa fa-eye"></i></button>
            <img src="<?php echo e($attachmentById); ?>" alt="">
            </div>
        <?php endif; ?>
        <?php if(istype($attachmentById, 'audio')): ?>
            <div class="col-md-6">
            <audio src="<?php echo e($attachmentById); ?>" controls preload="none"></audio>
            </div>
        <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(auth()->user()->id == $comment->user_id || auth()->user()->can('admin') || auth()->user()->can('superadmin')): ?>
    <div><a href="<?php echo e(route('comment.edit', $comment->id)); ?>" class="btn btn-sm btn-warning">ویرایش</a></div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addreference', $comment->request)): ?>
    <div><a href="<?php echo e(route('comment.approve', $comment->id)); ?>" class="btn btn-sm btn-success">تایید</a></div>
    <div><a href="<?php echo e(route('comment.disapprove', $comment->id)); ?>" class="btn btn-sm btn-danger">عدم تایید</a></div>
    <?php endif; ?>

    <hr>
    <?php echo $__env->make('partials.comments', ['comments' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php /**PATH C:\xampp\htdocs\view\resources\views/partials/comments.blade.php ENDPATH**/ ?>