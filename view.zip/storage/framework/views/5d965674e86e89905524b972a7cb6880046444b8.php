

<?php $__env->startSection('content'); ?>
<div class="card-header">مدیریت کوپن ها</div>

<div class="card-body">
    <a href="<?php echo e(route('coupon.create')); ?>" class="btn btn-primary">اضافه کردن کوپن جدید</a>
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <div class="row">
                <div class="col-md-3">نام: <?php echo e($coupon->code); ?></div>
                <div class="col-md-3">هزینه: <?php echo e($coupon->discount); ?> تومان</div>
                <div class="col-md-3">نوع: <?php echo e(__('app.'.$coupon->discount_type)); ?></div>
                <div class="col-md-3">تاریخ انقضا: <?php echo e($coupon->expire_at); ?></div>
                <div class="col-md-3">باقیمانده: <?php echo e($coupon->coupon_use ? $coupon->coupon_use : 'بی نهایت'); ?></div>
                <div class="col-md-3">تعداد: <?php echo e($coupon->use()->count()); ?></div>
                <div class="col-md-3">مجاز: <?php echo e($coupon->valid()); ?></div>
                <div class="col-md-3">
                    <form action="<?php echo e(route('coupon.destroy', $coupon->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm btn-danger">حذف</button>
                    </form>
                    <a href="<?php echo e(route('coupon.edit', $coupon->id)); ?>" class="btn btn-sm btn-primary">ویرایش</a>
                </div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($coupons->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/admin/coupon/index.blade.php ENDPATH**/ ?>