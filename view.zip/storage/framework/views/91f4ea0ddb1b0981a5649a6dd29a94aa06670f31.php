

<?php $__env->startSection('content'); ?>
<div class="card-header">مدیریت کاربران</div>

<div class="card-body">
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item <?php if(!$tr->status): ?> border border-danger <?php endif; ?>">
            <div class="row">
                <div class="col-md-2">نام: <?php echo e($tr->user->name); ?></div>
                <div class="col-md-2">هزینه: <?php echo e($tr->price); ?> تومان</div>
                <div class="col-md-6">شماره شبا: <?php echo e($tr->user->getMeta('shaba', true)); ?> تومان</div>
            </div>
            <div class="row">
                <div class="col <?php echo e($tr->status ? 'text-success' : 'text-danger'); ?>">وضعیت: <?php echo e($tr->status ? 'پرداخت شده' : 'پرداخت نشده'); ?></div>
                <?php if(!$tr->status): ?>
                <div class="col">
                    <form action="<?php echo e(route('wallet_order')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="id" value="<?php echo e($tr->id); ?>">
                        <input placeholder="کد پیگیری" class="form-control" type="text" name="authority" id="">
                        <input class="btn btn-primary" type="submit" value="پرداخت">
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($transactions->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/admin/user/wallet.blade.php ENDPATH**/ ?>