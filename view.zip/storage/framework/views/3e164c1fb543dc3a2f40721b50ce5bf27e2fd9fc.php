

<?php $__env->startSection('content'); ?>
   <div class="card-header">
       ثبت درخواست
   </div>
   <div class="card-body">
    <div class="row" id="question-from">
        <sendquestionform></sendquestionform>
    </div>
   </div>
   <script src="<?php echo e(asset('js/sendquestion.js')); ?>" type="module" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/question/send.blade.php ENDPATH**/ ?>