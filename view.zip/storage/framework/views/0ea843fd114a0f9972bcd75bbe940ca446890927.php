

<?php $__env->startSection('content'); ?>


<div class="card-header">تراکنش ها</div>

<div class="card-body">
    <ul class="list-group mt-3">
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item <?php if(!$tr->status): ?> border border-danger <?php endif; ?>">
            <div class="row">
                <div class="table-responsive col-md-5">
                    <table class="table-bordered">
                        <tr>
                            <th class="p-2">نام</th>
                            <td class="p-2"><?php echo e($tr->optionVar->option->name); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">نوع کارشناس</th>
                            <td class="p-2"><?php echo e($tr->optionVar->name); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="table-responsive col-md-4">
                    <table class="table-bordered">
                        <tr>
                            <th class="p-2">نوع بررسی</th>
                            <td class="p-2"><?php echo e($tr->optionType->name); ?></td>
                        </tr>
                        <tr>
                            <th class="p-2">قیمت</th>
                            <td class="p-2"><?php echo e($tr->price); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="table-responsive col-md-3">
                    <table class="table-bordered">
                        <tr>
                            <th class="p-2">
                                <?php if($tr->request): ?>
                                <a href="<?php echo e(route('user.request', $tr->request->id)); ?>" class="btn btn-primary">مشاهده سوال</a>
                                <?php else: ?>
                                <a href="<?php echo e(route('user.question_request', $tr->id)); ?>" class="btn btn-primary">ثبت سوال</a>
                                <?php endif; ?>
                            </th>
                        </tr>
                        <tr>
                            <th class="p-2">
                                کد تخفیف: <?php echo e($tr->coupon); ?>

                            </th>           
                        </tr>
                        <tr>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin','superadmin'])): ?>
                            <th class="p-2">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-user')): ?>
                                    <form method="post" action="<?php echo e(route('transaction.destroy', $tr->id)); ?>" class="confirm">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-sm btn-danger">حذف</button>
                                    </form>
                                <?php endif; ?>
                            </th>   
                            <?php endif; ?>
                        </tr>
                    </table>
                </div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($transactions->links()); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/customer/transaction/index.blade.php ENDPATH**/ ?>