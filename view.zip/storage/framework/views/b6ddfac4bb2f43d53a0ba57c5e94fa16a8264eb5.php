

<?php $__env->startSection('content'); ?>
<div class="card-header">تغییر اطلاعات کاربری</div>

<div class="card-body">
    <form method="POST" enctype="multipart/form-data" action="<?php echo e(($userid) ? route('user.a_change_data', $userid) : route('user.change_data')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group row">
            <label for="type" class="col-md-4 col-form-label text-md-right">عنوان</label>

            <div class="col-md-6">
                <select value="<?php echo e(old('type') ? old('type') :$user->role); ?>" name="type"  id="typeuserselect" class="form-control">
                    <option value="customer">کاربر</option>
                    <option value="expert_one">کارشناس</option>
                <?php if($userid): ?>
                    <option value="admin">ادمین</option>
                    <option value="expert_two">کارشناس دوم</option>
                <?php endif; ?>
                </select>

                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <?php if($userid): ?>
        <div class="form-group row">
            <div class="col-md-6">
                    <div class="form-group">
                        <label for="active">فعال</label>
                        <input type="radio" <?php if($user->getMeta('status', true) == 'active'): ?> checked <?php endif; ?> name="user_status" value="active" id="active">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label for="disable">غیر فعال</label>
                        <input type="radio" <?php if($user->getMeta('status', true) == 'disable'): ?> checked <?php endif; ?> name="user_status" value="disable" id="disable">
                    </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="form-group row">
            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('auth.name')); ?> <strong class="text-danger">*</strong></label>

            <div class="col-md-6">
                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name') ? old('name') : $user->name); ?>" required autocomplete="name" autofocus>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('auth.email')); ?> <strong class="text-danger">*</strong></label>

            <div class="col-md-6">
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email') ? old('email') : $user->email); ?>" required autocomplete="email">

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="phone" class="col-md-4 col-form-label text-md-right">تلفن <strong class="text-danger">*</strong></label>

            <div class="col-md-6">
                <input id="phone" type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone') ? old('phone') : $user->phone); ?>" required autocomplete="off">

                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div id="expert" class="edit" style="display: none;<?php if((old('type') ? old('type') : ($user->can('expert') ? 'expert' : 'customer')) == 'expert'): ?> display: block; <?php endif; ?>">
            <div class="form-group row">
                <label for="shaba" class="col-md-4 col-form-label text-md-right">شماره شبا <strong class="text-danger">*</strong></label>

                <div class="col-md-6">
                    <input id="shaba" minlength="22" maxlength="26" type="shaba" value="<?php echo e(old('shaba') ? old('shaba') : $user->getMeta('shaba', true)); ?>" class="form-control <?php $__errorArgs = ['shaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="shaba" autocomplete="off">

                    <?php $__errorArgs = ['shaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <hr>
            <p class="text-danger">حجم تصاویر باید زیر 300 کیلوبایت باشد</p>
            <div class="row flex-wrap">
                <div class="col-md-4 d-flex flex-column">
                    <p>تصویر کارت ملی</p>
                    <label for="cartmeli" class="btn btn-primary">بارگذاری</label>
                    <input type="file" name="cartmeli" accept="image/*" id="cartmeli" class="d-none file">
                    <?php $__errorArgs = ['cartmeli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img <?php if($user->hasMeta('cartmeli')): ?> src="<?php echo e(getAttachmentById($user->getMeta('cartmeli', true))); ?>" data-img="<?php echo e($user->getMeta('cartmeli', true)); ?>" <?php endif; ?>>
                </div>
                <div class="col-md-4 d-flex flex-column">
                    <p>کارت نظام دامپزشکی</p>   
                    <label for="nezampezeshki" class="btn btn-primary">بارگذاری</label>
                    <input type="file" name="nezampezeshki" accept="image/*" id="nezampezeshki" class="d-none file">
                    <?php $__errorArgs = ['nezampezeshki'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img <?php if($user->hasMeta('nezame_dampezeshki')): ?> src="<?php echo e(getAttachmentById($user->getMeta('nezame_dampezeshki', true))); ?>" data-img="<?php echo e($user->getMeta('nezame_dampezeshki', true)); ?>" <?php endif; ?>>
                </div>
                <div class="col-md-4 d-flex flex-column">
                    <p>کارت نظام تخصصی</p>
                    <label for="nezampezeshkit" class="btn btn-primary">بارگذاری</label>
                    <input type="file" name="nezampezeshkit" accept="image/*" id="nezampezeshkit" class="d-none file">
                    <?php $__errorArgs = ['nezampezeshkit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img <?php if($user->hasMeta('nezame_dampezeshki_t')): ?> src="<?php echo e(getAttachmentById($user->getMeta('nezame_dampezeshki_t', true))); ?>" data-img="<?php echo e($user->getMeta('nezame_dampezeshki_t', true)); ?>" <?php endif; ?>>
                </div>
            </div>
        </div>

        <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn border-primary text-primary">
                    <?php echo e(__('auth.register')); ?>

                </button>
            </div>
        </div>
    </form>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\view\resources\views/auth/edit.blade.php ENDPATH**/ ?>