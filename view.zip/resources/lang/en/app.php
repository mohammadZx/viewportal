<?php

return [
    'dashboard' => 'داشبورد',
    'create' => 'اضافه',
    'update' => 'بروز',
    'updated' => 'ویرایش شده',
    'new' => 'جدید',
    'mark' => 'مشاهده شده',
    'comment' => 'پاسخ داده شده',
    'WALLET' => 'کیف پول',
    'WALLET_CHARGE' => 'شارژ کیف پول',
    'percent' => 'درصدی',
    'static' => 'ثابت',
    'reference' => 'ارجاع'
];