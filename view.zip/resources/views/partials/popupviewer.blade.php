<div class="modal fade popupviewer" tabindex="-1" role="dialog" aria-labelledby="popupviewer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
  
    <div class="modal-content">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <p class="modal-title" id="myLargeModalLabel">مشاهده گر تصویر</p>
      </div>
        
    <div class="modal-body">
        @include('partials.viewer')
    </div>
    </div>
  </div>
</div>