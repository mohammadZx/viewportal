<?php

return [
    'dashboard' => 'داشبورد'
];