form = $('form.send-question')

options = JSON.parse(form.attr('data-jsonvars'));
selected = null;
allPrice = 0;
priceDiscounted = 0;
coupon = null;

function getOption(id) {
    return options.find(x => x.id == id);
}



for (option of options) {
    $('#option').append("<option value='" + option.id + "'>" + option.name + "</option>");
}
$('#option').on('change', function() {
    calcPrice();
    if (!$(this).val()) return;
    selected = getOption($(this).val());
    if (selected.content) {
        $(this).parent().children('.alert').addClass('active');
        $(this).parent().children('.alert').children('.message').text(selected.content);
    } else {
        $(this).parent().children('.alert').removeClass('active');
    }

    changeType()
    changeVar()
})




function changeType() {
    $('#option_type').text("");
    $('#option_type').append("<option value=''>نوع درخواست</option>")
    $('#option_type').parent().children('.alert').removeClass('active');
    for (type of selected.types) {
        $('#option_type').append("<option value='" + type.id + "'>" + type.name + " " + "(" + type.price + " هزار تومان)" + "</option>");
    }
}
$('#option_type').on('change', function() {
    calcPrice();
    if (!$(this).val()) return;
    option_type = selected.types.find(x => x.id == $(this).val());
    if (option_type.content) {
        $(this).parent().children('.alert').addClass('active');
        $(this).parent().children('.alert').children('.message').text(option_type.content);
    } else {
        $(this).parent().children('.alert').removeClass('active');
    }
})




function changeVar() {
    $('#option_var').text("");
    $('#option_var').append("<option value=''>نوع بررسی</option>")
    $('#option_var').parent().children('.alert').removeClass('active');
    for (type of selected.vars) {
        $('#option_var').append("<option value='" + type.id + "'>" + type.name + " " + "(" + type.price + " هزار تومان)" + "</option>");
    }
}
$('#option_var').on('change', function() {
    calcPrice();
    if (!$(this).val()) return;
    option_var = selected.vars.find(x => x.id == $(this).val());
    if (option_var.content) {
        $(this).parent().children('.alert').addClass('active');
        $(this).parent().children('.alert').children('.message').text(option_var.content);
    } else {
        $(this).parent().children('.alert').removeClass('active');
    }
})


function checkOptionParams() {
    typeval = $('#option_type').val()
    varval = $('#option_var').val()
    if (typeval && varval) return true;
    return false;
}

function calcPrice() {
    allPrice = 0;
    if (!checkOptionParams()) {
        $('#showprice .price').text(allPrice);
        return;
    }
    allPrice += selected.types.find(x => x.id == $("#option_type").val()).price
    allPrice += selected.vars.find(x => x.id == $("#option_var").val()).price
    $('#showprice .price').text(allPrice);
}


form.on('submit', function(e) {
    if (!checkOptionParams()) e.preventDefault();
});

console.log(options);