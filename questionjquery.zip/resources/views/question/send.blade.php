@extends('layouts.app')

@section('content')
   <div class="card-header">
       ثبت درخواست
   </div>
   <div class="card-body">
    <div class="row">
        <div class="col-md-6">
            <form action="" class="send-question" data-jsonvars="{{$options}}">
                <div class="form-group">
                    <label for="option">نوع درخواست</label>
                    <select required name="option" id="option" class="form-control"><option value="">نوع درخواست</option></select>
                    <div class="mt-2 unactive alert alert-sm alert-primary"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <span class="message"></span></div>
                </div>
                <div class="form-group">
                    <label for="option_type">سطح درخواست</label>
                    <select name="type" id="option_type" class="form-control" required><option value="">سطح درخواست</option></select>
                    <div class="mt-2 unactive alert alert-sm alert-primary"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <span class="message"></span></div>
                </div>
                <div class="form-group">
                    <label for="option_var">نوع بررسی</label>
                    <select name="var" id="option_var" class="form-control" required><option value="">نوع بررسی</option></select>
                    <div class="mt-2 unactive alert alert-sm alert-primary"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <span class="message"></span></div>
                </div>
                <div class="form-group">
                    <label for="coupon">کد تخفیف: </label>
                    <input type="text" name="coupon" id="coupon" class="form-control">
                    <div class="mt-2 alert alert-sm alert-warning"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <span class="message"></span></div>
                    <button class="mt-2 btn btn-primary btn-sm">ثبت</button>
                </div>
                <div class="form-group">
                    <button class="btn btn-danger btn-sm" id="showprice" type="button">هزینه کل: <span class="price">0</span></button>
                </div>
                <div class="form-group">
                    <button class="btn btn-success btn-sm">ثبت و پرداخت</button>
                </div>
            </form>
        </div>
    </div>
   </div>
@endsection